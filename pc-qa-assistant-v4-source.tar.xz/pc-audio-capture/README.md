# PC Q&A Assistant v4 — Ollama Cloud

Windows 11 desktop app (.NET 10 WinForms), extended from PC Sound Capture v3.

**Purpose:** Listen to spoken questions from your PC or microphone, transcribe
locally with Vosk, send the recognized **question text** to Ollama Cloud, and
show a short AI answer in the main window and an always-on-top floating overlay.
No audio recording is required. Typed questions work without any speech model.

## New in v4

- **Ollama Cloud is the default** and makes requests directly to
  `https://ollama.com/api/chat`. No local Ollama installation, downloaded LLM,
  or GPU is needed to generate answers.
- Cloud authentication uses `Authorization: Bearer <OLLAMA_API_KEY>`.
- A **cloud model** text field defaults to `gemma4:31b`. Enter another name
  returned by Ollama's cloud model listing or model catalog if needed.
  Note: direct API model names can differ from CLI model names ending `:cloud`.
- **API key field** with Save key/Remove key buttons. Saved secrets live in
  `%APPDATA%\PCSoundCapture\ollama-cloud-key.dpapi`, encrypted using Windows
  DPAPI for the current Windows account. They are **not** stored in `settings.json`
  or the project source. `OLLAMA_API_KEY` environment variable, if set, overrides
  the stored secret.
- Select **Local Ollama** in the UI to continue using a local installation and
  its old model/server settings; existing non-AI features remain intact.
- **Privacy:** By default only a recognized question (or a typed question) is
  sent to the cloud. Opt in to including recent speech context. Raw audio stays
  on your PC; Vosk recognition is local. Without explicit Save WAV / Save
  transcript checkboxes, neither audio nor transcript files are saved.

## Requirements

- Windows 11 x64
- .NET 10 SDK (to build/run source): https://dotnet.microsoft.com/download/dotnet/10.0
- An Ollama account with cloud API access, an API key, Internet connectivity,
  and usage allowance/credits as required by Ollama.
- For microphone/PC speech input: extracted Vosk language model from
  https://alphacephei.com/vosk/models (local speech recognition). No Vosk
  model is required to enter typed questions.

## Quick start

1. Create your Ollama API key at https://ollama.com/settings/keys . **Do not
   share your key** or commit it to GitHub.
2. Unzip the source, open PowerShell in `PCSoundCapture`, and run:

   ```powershell
   dotnet restore
   dotnet run
   ```

3. Ensure AI provider is **Ollama Cloud**, and the AI model is `gemma4:31b`
   (or one of your available cloud models). Paste the API key and click
   **Save key**.
4. Type a question in the lower panel and click **Ask AI** to verify the
   connection before configuring audio devices.
5. For spoken questions, select a Vosk model folder, audio source and
   microphone (if wanted), then click **Start listening**. Detected questions
   automatically produce answers in the floating window.

Alternatively, set `OLLAMA_API_KEY` before launching the app:

```powershell
$env:OLLAMA_API_KEY = Read-Host "Ollama API key"
dotnet run
```

This example configures the key only in the current PowerShell process. The
app can also store an encrypted key through the UI for subsequent launches.

## How it works

- Audio sources: system speaker loopback, per-application audio (process +
  children, using Windows process loopback support), microphone alone, or a
  microphone combined with PC/application audio.
- Speech recognition: offline Vosk; utterances are assembled and checked for
  question patterns. The question detector is heuristic and may miss questions
  or confuse statements with questions. Typed questions can always be used.
- Q&A: `/api/chat` (non-streaming) with a brief assistant system prompt. For
  cloud mode it uses `https://ollama.com/api/chat` over HTTPS. For local mode
  it uses your configured local Ollama server.
- User interface: transcript, AI answer panel, always-on-top answer overlay,
  recording duration, output selection, optional WAV/transcript saving, and
  system tray background operation.

## Build a Windows EXE

Run `BUILD-WINDOWS.ps1` in the project folder. It calls .NET publish to produce
an executable. NuGet restore and build require network access for packages.

## Privacy and limitations

- Cloud mode sends recognized question text (and optional prior conversation
  text if checked) to Ollama Cloud for processing. Make sure meeting
  participants and relevant policies permit sending these words to a third party.
- Ollama's cloud plan limits, pricing, model names and availability can change.
  Check https://docs.ollama.com/cloud and your Ollama account settings.
- An API key must remain secret. The Windows DPAPI file is tied to the Windows
  user profile. An `OLLAMA_API_KEY` environment variable takes precedence.
- Vosk still needs a local speech recognition model and may make transcription
  errors. This release does **not** use Ollama for speech-to-text.
- All key persistence uses the local Windows profile and does not touch GitHub.
- The project was structurally reviewed in this environment, **not compiled or
  run on Windows**. Test it on a Windows computer with a valid API key.

## Official documentation

- https://docs.ollama.com/cloud
- https://docs.ollama.com/api/introduction
- https://docs.ollama.com/api/authentication
- https://ollama.com/search?c=cloud
